let name = "jameel";
let age = 49;

console.log(`My name is ${name} and my age is ${age}`);